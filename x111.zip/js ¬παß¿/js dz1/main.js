console.log("Задание 1");
let city = "Ровно",
    country = "Украина",
    population = 243934,
    footballStadium = true; 
console.log(city, country, population, footballStadium);

console.log("Задание 2");
let height = 40,
    width = 70,
    square;

square = height * width; 
console.log(square);

console.log("Задание 3");
let time = 2,
    speedOfFirst = 95,
    speedOfSecond = 114;

let speedTogether = speedOfFirst + speedOfSecond;
let distance = speedTogether / time;
console.log(distance);

console.log("Задание 4");
const randomNumber = Math.floor(Math.random() * 100);
console.log(randomNumber);
if (randomNumber < 20){
    console.log("randomNumber меньше 20");
} else if (randomNumber > 50){
    console.log("randomNumber больше 50");
} else {
    console.log("randomNumber больше 20, и меньше 50");
}

console.log("Задание 5");
switch(randomNumber){
    case (randomNumber < 20) : 
        console.log("randomNumber меньше 20");
        break;
    case (randomNumber > 50) : 
        console.log("randomNumber больше 50");
        break;
    default: 
        console.log("randomNumber больше 20, и меньше 50");

};